package com.example.ejonespringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class EjOneSpringBootApplication {

    public static void main(String[] args) {
        SpringApplication.run(EjOneSpringBootApplication.class, args);
    }

}
